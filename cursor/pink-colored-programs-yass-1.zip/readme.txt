﻿=== Gaming In Pink Icon Set ===

By: tauruzsun (http://www.rw-designer.com/user/107572) luciaemedina9@gmail.com

Download: http://www.rw-designer.com/icon-set/pink-colored-programs-yass-1

Author's description:

i do not own the original diluc hoyoverse picture edit, i only edited it to look pink. the creator is kakuhisui (on pinterest)!!!

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.