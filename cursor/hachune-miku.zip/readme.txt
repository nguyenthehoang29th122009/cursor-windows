﻿=== Hachune Miku Cursor Set ===

By: Roman (http://www.rw-designer.com/user/92742) dawnkanderson3@gmail.com

Download: http://www.rw-designer.com/cursor-set/hachune-miku

Author's description:

For the Hatsune Miku anime lovers!

This one took a long time to make because of the animations.

Hope you enjoy it!

P.S Some of the cursors might not work from my laziness.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.