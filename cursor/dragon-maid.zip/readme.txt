﻿=== Miss Kobayashi's Dragon Maid Cursor Set ===

By: Vini e Digo CHANNEL (http://www.rw-designer.com/user/52673)

Download: http://www.rw-designer.com/cursor-set/dragon-maid

Author's description:

Miss Kobayashi's Dragon Maid (Or Kobayashi-san Chi no Maid Dragon) is one of my favorites anime, and I create 9 cursors for this set.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.